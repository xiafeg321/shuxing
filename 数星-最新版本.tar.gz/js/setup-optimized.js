// 数星 - 优化版人格设置页面JavaScript

// 人格特征数据
const personalityData = {
    zodiac: {
        '白羊': { name: '白羊座', trait: '热情直接，行动力强，喜欢挑战', element: 'fire', symbol: '♈' },
        '金牛': { name: '金牛座', trait: '稳重固执，注重实际，享受生活', element: 'earth', symbol: '♉' },
        '双子': { name: '双子座', trait: '多变好奇，善于沟通，思维敏捷', element: 'air', symbol: '♊' },
        '巨蟹': { name: '巨蟹座', trait: '敏感体贴，家庭为重，情感丰富', element: 'water', symbol: '♋' },
        '狮子': { name: '狮子座', trait: '自信领导，喜欢关注，慷慨大方', element: 'fire', symbol: '♌' },
        '处女': { name: '处女座', trait: '细致完美，注重细节，服务他人', element: 'earth', symbol: '♍' },
        '天秤': { name: '天秤座', trait: '平衡和谐，追求美感，善于交际', element: 'air', symbol: '♎' },
        '天蝎': { name: '天蝎座', trait: '深沉神秘，情感强烈，直觉敏锐', element: 'water', symbol: '♏' },
        '射手': { name: '射手座', trait: '自由乐观，热爱冒险，思想开放', element: 'fire', symbol: '♐' },
        '摩羯': { name: '摩羯座', trait: '务实责任，目标明确，耐心坚持', element: 'earth', symbol: '♑' },
        '水瓶': { name: '水瓶座', trait: '独立创新，思想独特，人道主义', element: 'air', symbol: '♒' },
        '双鱼': { name: '双鱼座', trait: '浪漫感性，富有同情，想象力丰富', element: 'water', symbol: '♓' }
    },
    
    mbti: {
        'INTJ': { name: 'INTJ', trait: '战略思考，独立自主，追求效率', category: 'analyst' },
        'INTP': { name: 'INTP', trait: '逻辑分析，好奇心强，理论思维', category: 'analyst' },
        'ENTJ': { name: 'ENTJ', trait: '领导决策，目标导向，组织能力强', category: 'analyst' },
        'ENTP': { name: 'ENTP', trait: '创新辩论，头脑灵活，喜欢挑战', category: 'analyst' },
        'INFJ': { name: 'INFJ', trait: '理想洞察，富有同情，追求意义', category: 'diplomat' },
        'INFP': { name: 'INFP', trait: '理想价值，敏感细腻，忠于信念', category: 'diplomat' },
        'ENFJ': { name: 'ENFJ', trait: '激励引导，善于交际，关心他人', category: 'diplomat' },
        'ENFP': { name: 'ENFP', trait: '热情创意，充满灵感，乐观积极', category: 'diplomat' },
        'ISTJ': { name: 'ISTJ', trait: '责任传统，务实可靠，注重细节', category: 'sentinel' },
        'ISFJ': { name: 'ISFJ', trait: '支持关怀，细致负责，保护他人', category: 'sentinel' },
        'ESTJ': { name: 'ESTJ', trait: '组织管理，高效务实，遵守规则', category: 'sentinel' },
        'ESFJ': { name: 'ESFJ', trait: '社交和谐，乐于助人，注重传统', category: 'sentinel' },
        'ISTP': { name: 'ISTP', trait: '实用解决，冷静分析，动手能力强', category: 'explorer' },
        'ISFP': { name: 'ISFP', trait: '审美体验，温和敏感，享受当下', category: 'explorer' },
        'ESTP': { name: 'ESTP', trait: '行动适应，精力充沛，现实导向', category: 'explorer' },
        'ESFP': { name: 'ESFP', trait: '活力社交，热情开朗，享受生活', category: 'explorer' }
    }
};

// 用户选择的数据
let userSelections = {
    zodiac: null,
    mbti: null,
    chatHistory: ''
};

// 当前步骤
let currentStep = 1;
const totalSteps = 4;

document.addEventListener('DOMContentLoaded', function() {
    console.log('优化版人格设置页面加载完成');
    
    // 初始化页面
    initOptimizedSetup();
    
    // 加载保存的数据
    loadSavedSelections();
});

// 初始化优化版设置页面
function initOptimizedSetup() {
    console.log('初始化优化版设置页面...');
    
    // 生成星座卡片
    generateZodiacCards();
    
    // 生成MBTI卡片
    generateMbtiCards();
    
    // 初始化字符计数
    updateCharCount();
    
    // 更新进度指示
    updateProgress();
    
    // 绑定事件
    bindOptimizedEvents();
    
    console.log('优化版设置页面初始化完成');
}

// 生成星座卡片
function generateZodiacCards() {
    const zodiacGrid = document.getElementById('zodiac-grid');
    if (!zodiacGrid) {
        console.error('找不到星座网格元素');
        return;
    }
    
    zodiacGrid.innerHTML = '';
    
    Object.entries(personalityData.zodiac).forEach(([key, data]) => {
        const zodiacCard = document.createElement('div');
        zodiacCard.className = 'zodiac-card';
        zodiacCard.dataset.zodiac = key;
        
        // 提取简短特征（前8个字符）
        const shortTrait = data.trait.length > 8 ? data.trait.substring(0, 8) + '...' : data.trait;
        
        zodiacCard.innerHTML = `
            <div class="zodiac-symbol">${data.symbol}</div>
            <div class="zodiac-name">${data.name}</div>
            <div class="zodiac-element ${data.element}">${getElementText(data.element)}</div>
            <div class="zodiac-trait">${shortTrait}</div>
        `;
        
        zodiacGrid.appendChild(zodiacCard);
    });
    
    console.log(`生成了 ${Object.keys(personalityData.zodiac).length} 个星座卡片`);
}

// 生成MBTI卡片
function generateMbtiCards() {
    const mbtiGrid = document.getElementById('mbti-grid');
    if (!mbtiGrid) {
        console.error('找不到MBTI网格元素');
        return;
    }
    
    mbtiGrid.innerHTML = '';
    
    Object.entries(personalityData.mbti).forEach(([key, data]) => {
        const mbtiCard = document.createElement('div');
        mbtiCard.className = 'mbti-card';
        mbtiCard.dataset.mbti = key;
        
        mbtiCard.innerHTML = `
            <div class="mbti-header">
                <div class="mbti-type">${data.name}</div>
                <div class="mbti-category ${data.category}">${getCategoryText(data.category)}</div>
            </div>
            <div class="mbti-trait">${data.trait}</div>
        `;
        
        mbtiGrid.appendChild(mbtiCard);
    });
    
    console.log(`生成了 ${Object.keys(personalityData.mbti).length} 个MBTI卡片`);
}

// 获取元素文本
function getElementText(element) {
    const elementMap = {
        'fire': '火象星座',
        'earth': '土象星座',
        'air': '风象星座',
        'water': '水象星座'
    };
    return elementMap[element] || element;
}

// 获取分类文本
function getCategoryText(category) {
    const categoryMap = {
        'analyst': '分析师',
        'diplomat': '外交家',
        'sentinel': '守护者',
        'explorer': '探险家'
    };
    return categoryMap[category] || category;
}

// 绑定优化版事件
function bindOptimizedEvents() {
    console.log('绑定优化版事件...');
    
    // 星座卡片点击事件
    document.addEventListener('click', function(e) {
        const zodiacCard = e.target.closest('.zodiac-card');
        if (zodiacCard) {
            selectZodiac(zodiacCard.dataset.zodiac);
        }
        
        const mbtiCard = e.target.closest('.mbti-card');
        if (mbtiCard) {
            selectMbti(mbtiCard.dataset.mbti);
        }
    });
    
    // 下一步按钮
    const nextButtons = document.querySelectorAll('.next-btn');
    nextButtons.forEach(btn => {
        btn.addEventListener('click', nextStep);
    });
    
    // 上一步按钮
    const prevButtons = document.querySelectorAll('.prev-btn');
    prevButtons.forEach(btn => {
        btn.addEventListener('click', prevStep);
    });
    
    // 聊天记录输入
    const chatInput = document.getElementById('chat-history');
    if (chatInput) {
        chatInput.addEventListener('input', updateCharCount);
        
        // 自动调整高度
        chatInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 300) + 'px';
        });
    }
    
    // 清空文本按钮
    const clearTextBtn = document.getElementById('clear-text-btn');
    if (clearTextBtn) {
        clearTextBtn.addEventListener('click', function() {
            const chatInput = document.getElementById('chat-history');
            if (chatInput) {
                chatInput.value = '';
                updateCharCount();
            }
        });
    }
    
    // 示例文本按钮
    const exampleTextBtn = document.getElementById('example-text-btn');
    if (exampleTextBtn) {
        exampleTextBtn.addEventListener('click', function() {
            const examples = [
                "你：今天过得怎么样？\nTA：还不错，刚看完一部电影~\n你：什么电影呀？好看吗？\nTA：《星际穿越》，超级震撼！推荐你看！\n你：好呀，周末一起看？\nTA：好呀好呀，期待~ 😊",
                "你：工作好累啊，今天又被老板说了...\nTA：抱抱你，别太难过了~\n你：好想辞职😭\nTA：先别急，慢慢来，我陪着你",
                "你：周末有什么计划吗？\nTA：我想去那家新开的咖啡馆试试\n你：听起来不错！要一起吗？\nTA：好呀，下午3点怎么样？\n你：完美！到时候见~",
                "你：最近在看什么好看的剧吗？\nTA：我在追《黑暗荣耀》，超级好看！\n你：我也听说过！讲什么的呀？\nTA：关于校园暴力和复仇的，剧情很精彩\n你：那我也要看看！"
            ];
            
            const randomExample = examples[Math.floor(Math.random() * examples.length)];
            const chatInput = document.getElementById('chat-history');
            if (chatInput) {
                chatInput.value = randomExample;
                updateCharCount();
                
                // 触发高度调整
                chatInput.style.height = 'auto';
                chatInput.style.height = Math.min(chatInput.scrollHeight, 300) + 'px';
            }
        });
    }
    
    // 文件上传
    const fileSelectBtn = document.getElementById('file-select-btn');
    const fileInput = document.getElementById('file-input');
    const fileUploadArea = document.getElementById('file-upload-area');
    
    if (fileSelectBtn && fileInput) {
        // 点击按钮触发文件选择
        fileSelectBtn.addEventListener('click', function() {
            fileInput.click();
        });
        
        // 拖放功能
        fileUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.style.borderColor = '#8c98ff';
            this.style.background = '#f0f2ff';
        });
        
        fileUploadArea.addEventListener('dragleave', function() {
            this.style.borderColor = '#cbd5e0';
            this.style.background = '#f8f9ff';
        });
        
        fileUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.style.borderColor = '#cbd5e0';
            this.style.background = '#f8f9ff';
            
            if (e.dataTransfer.files.length > 0) {
                handleFileUpload(e.dataTransfer.files[0]);
            }
        });
        
        // 文件选择变化
        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) {
                handleFileUpload(this.files[0]);
            }
        });
    }
    
    // 完成按钮（在完成设置部分）
    const completeBtn = document.getElementById('complete-btn');
    if (completeBtn) {
        completeBtn.addEventListener('click', completeSetup);
    }
    
    console.log('优化版事件绑定完成');
}

// 选择星座
function selectZodiac(zodiacKey) {
    console.log('选择星座:', zodiacKey);
    
    // 移除之前的选择
    document.querySelectorAll('.zodiac-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // 添加当前选择
    const selectedCard = document.querySelector(`.zodiac-card[data-zodiac="${zodiacKey}"]`);
    if (selectedCard) {
        selectedCard.classList.add('selected');
    }
    
    // 保存选择
    userSelections.zodiac = zodiacKey;
    
    // 显示预览
    const preview = document.getElementById('zodiac-preview');
    const selectedZodiac = document.getElementById('selected-zodiac');
    const zodiacDescription = document.getElementById('zodiac-description');
    
    if (preview && selectedZodiac && zodiacDescription) {
        const zodiacData = personalityData.zodiac[zodiacKey];
        selectedZodiac.textContent = zodiacData.name;
        zodiacDescription.textContent = zodiacData.trait;
        preview.style.display = 'block';
    }
    
    // 保存到本地存储
    saveSelections();
}

// 选择MBTI
function selectMbti(mbtiKey) {
    console.log('选择MBTI:', mbtiKey);
    
    // 移除之前的选择
    document.querySelectorAll('.mbti-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // 添加当前选择
    const selectedCard = document.querySelector(`.mbti-card[data-mbti="${mbtiKey}"]`);
    if (selectedCard) {
        selectedCard.classList.add('selected');
    }
    
    // 保存选择
    userSelections.mbti = mbtiKey;
    
    // 显示预览
    const preview = document.getElementById('mbti-preview');
    const selectedMbti = document.getElementById('selected-mbti');
    const mbtiDescription = document.getElementById('mbti-description');
    
    if (preview && selectedMbti && mbtiDescription) {
        const mbtiData = personalityData.mbti[mbtiKey];
        selectedMbti.textContent = mbtiData.name;
        mbtiDescription.textContent = mbtiData.trait;
        preview.style.display = 'block';
    }
    
    // 保存到本地存储
    saveSelections();
}

// 更新字符计数
function updateCharCount() {
    const chatInput = document.getElementById('chat-history');
    const charCount = document.getElementById('char-count');
    
    if (!chatInput || !charCount) return;
    
    const count = chatInput.value.length;
    charCount.textContent = count;
    
    // 保存聊天记录
    userSelections.chatHistory = chatInput.value;
    saveSelections();
}

// 处理文件上传
function handleFileUpload(file) {
    console.log('处理文件上传:', file.name);
    
    // 检查文件类型
    if (!file.name.toLowerCase().endsWith('.txt')) {
        alert('请选择 .txt 文本文件');
        return;
    }
    
    // 检查文件大小（最大2MB）
    if (file.size > 2 * 1024 * 1024) {
        alert('文件太大，请选择小于2MB的文件');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const content = e.target.result;
        
        // 更新聊天记录输入框
        const chatInput = document.getElementById('chat-history');
        if (chatInput) {
            chatInput.value = content;
            updateCharCount();
            
            // 触发高度调整
            chatInput.style.height = 'auto';
            chatInput.style.height = Math.min(chatInput.scrollHeight, 300) + 'px';
        }
        
        // 显示文件信息
        const fileUploadInfo = document.getElementById('file-upload-info');
        const fileDetails = document.getElementById('file-details');
        
        if (fileUploadInfo && fileDetails) {
            const fileSize = (file.size / 1024).toFixed(2);
            const lineCount = content.split('\n').length;
            const charCount = content.length;
            
            fileDetails.innerHTML = `
                <strong>文件名：</strong>${file.name}<br>
                <strong>文件大小：</strong>${fileSize} KB<br>
                <strong>行数：</strong>${lineCount} 行<br>
                <strong>字符数：</strong>${charCount} 字符
            `;
            
            fileUploadInfo.classList.add('show');
            
            // 3秒后自动隐藏
            setTimeout(() => {
                fileUploadInfo.classList.remove('show');
            }, 3000);
        }
        
        console.log('文件上传成功:', file.name, fileSize + 'KB', lineCount + '行');
    };
    
    reader.onerror = function() {
        alert('读取文件失败，请重试');
    };
    
    reader.readAsText(file, 'UTF-8');
}

// 更新进度指示
function updateProgress() {
    // 更新步骤指示器
    document.querySelectorAll('.progress-step').forEach((step, index) => {
        const stepNumber = index + 1;
        
        if (stepNumber === currentStep) {
            step.classList.add('active');
        } else if (stepNumber < currentStep) {
            step.classList.remove('active');
            step.classList.add('completed');
        } else {
            step.classList.remove('active', 'completed');
        }
    });
    
    // 显示当前步骤
    document.querySelectorAll('.setup-section').forEach((section, index) => {
        const sectionNumber = index + 1;
        
        if (sectionNumber === currentStep) {
            section.classList.add('active');
            section.style.display = 'block';
        } else {
            section.classList.remove('active');
            section.style.display = 'none';
        }
    });
}

// 下一步
function nextStep() {
    if (currentStep < totalSteps) {
        currentStep++;
        updateProgress();
    }
}

// 上一步
function prevStep() {
    if (currentStep > 1) {
        currentStep--;
        updateProgress();
    }
}

// 完成设置
function completeSetup() {
    console.log('完成人格设置:', userSelections);
    
    // 验证必填项
    if (!userSelections.zodiac || !userSelections.mbti) {
        alert('请先选择星座和MBTI类型');
        return;
    }
    
    // 创建人格模型
    const model = {
        modelId: 'model_' + Date.now(),
        zodiac: userSelections.zodiac,
        mbti: userSelections.mbti,
        chatHistory: userSelections.chatHistory,
        createdAt: new Date().toISOString()
    };
    
    try {
        // 保存到本地存储
        localStorage.setItem('shuxing_user_settings', JSON.stringify(userSelections));
        localStorage.setItem('shuxing_current_model', JSON.stringify(model));
        
        console.log('人格模型已保存:', model);
        
        // 显示成功消息
        alert('人格模型创建成功！\n\n现在可以开始对话了。');
        
        // 跳转到对话页面
        window.location.href = 'chat.html';
        
    } catch (error) {
        console.error('保存模型失败:', error);
        alert('保存失败，请检查浏览器设置');
    }
}

// 保存选择到本地存储
function saveSelections() {
    try {
        localStorage.setItem('shuxing_user_settings', JSON.stringify(userSelections));
        console.log('选择已保存:', userSelections);
    } catch (error) {
        console.error('保存选择失败:', error);
    }
}

// 从本地存储加载选择
function loadSavedSelections() {
    try {
        const saved = localStorage.getItem('shuxing_user_settings');
        if (saved) {
            const parsed = JSON.parse(saved);
            userSelections = { ...userSelections, ...parsed };
            console.log('已加载保存的选择:', userSelections);
            
            // 恢复UI状态
            if (userSelections.zodiac) {
                selectZodiac(userSelections.zodiac);
            }
            
            if (userSelections.mbti) {
                selectMbti(userSelections.mbti);
            }
            
            if (userSelections.chatHistory) {
                const chatInput = document.getElementById('chat-history');
                if (chatInput) {
                    chatInput.value = userSelections.chatHistory;
                    updateCharCount();
                }
            }
        }
    } catch (error) {
        console.error('加载保存的选择失败:', error);
    }
}

console.log('优化版人格设置页面JavaScript加载完成');